import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { LifestyleSection } from './components/LifestyleSection';
import { PinkShowcase } from './components/PinkShowcase';
import { ProductGrid } from './components/ProductGrid';
import { ReviewsSection } from './components/ReviewsSection';
import { Footer } from './components/Footer';
import { MenuDrawer } from './components/MenuDrawer';

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollTo = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#016450] text-white flex flex-col font-sans selection:bg-[#fedb3f] selection:text-black">
      
      {/* Top Header - Exact match to the reference screenshot */}
      <Header
        onOpenMenu={() => setIsMenuOpen(true)}
        onOpenProjects={() => scrollTo('campaigns')}
        projectCount={4}
      />

      {/* Main Content Sections - Exact Layout without dense texts */}
      <main className="flex-1 w-full">
        {/* Top Hero: Monumental ANNA SILVA in rosa branca */}
        <Hero />

        {/* Full-width Advertising Campaign Visual with wave transition & portrait */}
        <LifestyleSection />

        {/* Hot Pink Section: About Me */}
        <PinkShowcase />

        {/* 4 Selected Advertising & Propaganda Campaigns */}
        <ProductGrid onSelectProject={() => scrollTo('campaign-visual')} />

        {/* Prestigious Awards & Festival Recognition Strip */}
        <ReviewsSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Menu Drawer */}
      <MenuDrawer
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        onNavigate={scrollTo}
      />

    </div>
  );
}
