import React from 'react';

interface WaveDividerProps {
  color?: string; // hex color of the wave fill
  className?: string;
  flip?: boolean;
}

export const WaveDivider: React.FC<WaveDividerProps> = ({
  color = '#25320c', // Exact green tone of Anna Silva's portrait background
  className = '',
  flip = false
}) => {
  return (
    <div
      className={`w-full bg-[#016450] overflow-hidden leading-none select-none pointer-events-none -mb-[1px] ${className}`}
      style={{ transform: flip ? 'rotate(180deg)' : undefined }}
    >
      <svg
        viewBox="0 0 1440 110"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-12 sm:h-16 md:h-20 lg:h-24 block"
        preserveAspectRatio="none"
      >
        {/* Organic wave shape matching ONDA_39a14299.PNG */}
        <path
          d="M0,58 C220,16 410,12 610,54 C810,96 1010,85 1190,32 C1310,0 1390,22 1440,42 L1440,110 L0,110 Z"
          fill={color}
        />
      </svg>
    </div>
  );
};
