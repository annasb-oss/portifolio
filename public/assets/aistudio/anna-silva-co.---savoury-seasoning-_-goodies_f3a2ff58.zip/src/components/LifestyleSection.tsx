import React from 'react';

export const LifestyleSection: React.FC = () => {
  return (
    <section id="campaign-visual" className="relative w-full bg-[#25320c] overflow-hidden select-none">
      
      {/* Wave Transition: Banner green (#016450) on top, curving into Anna's photo green (#25320c) */}
      <div className="relative w-full bg-[#016450] -mb-[1px] z-20 pointer-events-none">
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-14 sm:h-20 md:h-28 lg:h-36 block"
          preserveAspectRatio="none"
        >
          {/* Organic wave curve matching ONDA_39a14299.PNG */}
          <path
            d="M0,58 C220,16 410,12 610,54 C810,96 1010,85 1190,32 C1310,0 1390,22 1440,42 L1440,120 L0,120 Z"
            fill="#25320c"
          />
        </svg>
      </div>

      {/* Full-width Editorial Portrait of Anna Silva - Head dissolves smoothly under the wave */}
      <div className="relative w-full overflow-hidden max-h-[780px] flex items-center justify-center bg-[#25320c] -mt-10 sm:-mt-16 md:-mt-24 z-10">
        <img
          src="/assets/aistudio/Retrato_elegante_com_sorriso_suave_c6ff7cf3.png"
          alt="Anna Silva - Publicidade & Propaganda"
          className="w-full h-auto max-h-[780px] object-cover object-top block"
          style={{
            /* Smooth mask so the top cut of Anna's head dissolves completely into the wave and background */
            maskImage: 'linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.4) 10%, black 24%, black 100%)',
            WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.4) 10%, black 24%, black 100%)'
          }}
        />

        {/* Minimal Editorial Badge overlay in the corner */}
        <div className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 z-20">
          <div className="bg-black/60 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-white/20 text-[10px] sm:text-xs font-hero tracking-widest text-[#fedb3f] uppercase">
            ANNA SILVA // CREATIVE DIRECTION & EDITORIAL
          </div>
        </div>
      </div>

    </section>
  );
};
