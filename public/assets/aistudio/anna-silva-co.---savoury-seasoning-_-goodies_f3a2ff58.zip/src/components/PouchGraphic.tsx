import React from 'react';

interface PouchProps {
  color?: string; // pouch primary color e.g. #065c4c or #df0b76
  textColor?: string;
  flavorTitle: string;
  subtitle?: string;
  variant?: 'green' | 'pink' | 'blue' | 'orange';
  className?: string;
  badgeText?: string;
  rotation?: number; // degrees
  shadow?: boolean;
}

export const PouchGraphic: React.FC<PouchProps> = ({
  color = '#065c4c',
  textColor = '#fde01a',
  flavorTitle = 'CHEESY IMMATURE ANNA SILVA',
  subtitle = 'CHEESE FLAVOURED NUTRITIONAL YEAST',
  variant = 'green',
  className = '',
  badgeText,
  rotation = 0,
  shadow = true
}) => {
  const isPink = variant === 'pink' || color === '#df0b76';

  return (
    <div
      style={{
        transform: rotation ? `rotate(${rotation}deg)` : undefined,
        transformOrigin: 'center center'
      }}
      className={`relative inline-block transition-transform duration-300 hover:scale-105 select-none ${className}`}
    >
      {/* Pouch Container */}
      <div
        className={`relative w-56 sm:w-64 md:w-72 rounded-3xl p-5 pt-7 pb-6 flex flex-col items-center justify-between overflow-hidden border-2 border-black/20 ${
          shadow ? 'shadow-[0_25px_40px_-15px_rgba(0,0,0,0.5)]' : ''
        }`}
        style={{
          backgroundColor: color,
          color: textColor,
          minHeight: '340px'
        }}
      >
        {/* Subtle pouch foil gradient shine overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-black/20 via-transparent to-white/15 pointer-events-none" />
        
        {/* Top Pouch Seal / Zipper notch simulation */}
        <div className="w-full flex items-center justify-between border-b border-black/20 pb-3 mb-2 opacity-80">
          <div className="w-2 h-1 bg-black/30 rounded-full" />
          <div className="flex items-center gap-1.5 text-[9px] font-bold tracking-widest uppercase opacity-90">
            <span>✦</span>
            <span>ANNA SILVA CO.</span>
            <span>✦</span>
          </div>
          <div className="w-2 h-1 bg-black/30 rounded-full" />
        </div>

        {/* Badge if provided */}
        {badgeText && (
          <div className="absolute -top-1 -right-1 bg-[#fde01a] text-black font-black text-[10px] tracking-widest px-2.5 py-1 rounded-full shadow-md uppercase rotate-6 border border-black/30">
            {badgeText}
          </div>
        )}

        {/* Flavor title */}
        <div className="text-center my-auto w-full z-10 px-1">
          <div className="text-xs font-black tracking-widest text-white/90 mb-1">
            + {flavorTitle.split(' ANNA')[0] || flavorTitle} +
          </div>
          <div className="text-xl sm:text-2xl font-black font-condensed uppercase tracking-tight leading-none text-[#fde01a] drop-shadow-sm">
            ANNA SILVA
          </div>
          <div className="text-[9px] font-bold tracking-widest uppercase mt-1 opacity-80 text-white/90">
            {subtitle}
          </div>
        </div>

        {/* Mascot inside pouch banner */}
        <div className="my-2 p-2 bg-[#fde01a] rounded-2xl w-24 h-24 sm:w-28 sm:h-28 flex flex-col items-center justify-center border-2 border-black/20 text-black shadow-inner relative z-10">
          {/* Cute quirky cartoon doodle mascot */}
          <svg viewBox="0 0 100 100" className="w-full h-full fill-current">
            {/* Mascot Body: happy chunk with shades */}
            <path
              d="M25,35 Q15,55 25,75 Q40,85 70,80 Q85,75 80,45 Q75,25 50,25 Q30,25 25,35 Z"
              fill={isPink ? '#fde01a' : '#fde01a'}
              stroke="#000"
              strokeWidth="4"
              strokeLinejoin="round"
            />
            {/* Cool Sunglasses */}
            <rect x="30" y="40" width="18" height="12" rx="3" fill="#000" />
            <rect x="52" y="40" width="18" height="12" rx="3" fill="#000" />
            <line x1="48" y1="45" x2="52" y2="45" stroke="#000" strokeWidth="3" />
            {/* White shine on glasses */}
            <line x1="33" y1="43" x2="43" y2="43" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
            <line x1="55" y1="43" x2="65" y2="43" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
            {/* Big Smile */}
            <path d="M38,62 Q50,72 64,62" fill="none" stroke="#000" strokeWidth="4" strokeLinecap="round" />
            {/* Muscular/waving cartoon arms */}
            <path d="M22,48 Q10,40 12,30 Q16,38 20,42" fill="#fde01a" stroke="#000" strokeWidth="3" />
            <path d="M78,48 Q90,40 88,30 Q84,38 80,42" fill="#fde01a" stroke="#000" strokeWidth="3" />
            {/* Legs */}
            <path d="M35,78 L33,88 L27,88" fill="none" stroke="#000" strokeWidth="3" strokeLinecap="round" />
            <path d="M65,78 L67,88 L73,88" fill="none" stroke="#000" strokeWidth="3" strokeLinecap="round" />
          </svg>
          <span className="text-[8px] font-black tracking-tight uppercase mt-0.5">
            THE CRUNCH
          </span>
        </div>

        {/* Pouch Bottom seal */}
        <div className="w-full flex items-center justify-between pt-2 border-t border-black/20 text-[10px] font-bold opacity-90 z-10">
          <div className="flex items-center gap-1">
            <span className="w-4 h-4 rounded-full border border-current flex items-center justify-center text-[8px] font-black">
              V
            </span>
            <span className="text-[9px] uppercase tracking-wider">VEGAN</span>
          </div>
          <span className="text-[9px] uppercase tracking-widest font-black">
            100G ℮
          </span>
        </div>
      </div>
    </div>
  );
};
