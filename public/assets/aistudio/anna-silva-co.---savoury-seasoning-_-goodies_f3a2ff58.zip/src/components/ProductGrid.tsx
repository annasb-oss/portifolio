import React from 'react';
import { PRODUCTS } from '../data/products';
import { PouchGraphic } from './PouchGraphic';

interface ProductGridProps {
  onSelectProject?: (projectId: string) => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({ onSelectProject }) => {
  const campaignTags = [
    'BRAND IDENTITY & PACKAGING',
    'OOH & PRINT CAMPAIGN',
    'DIGITAL & SOCIAL ADS',
    'CREATIVE DIRECTION & FILM'
  ];

  return (
    <section id="campaigns" className="relative bg-[#016450] text-white py-12 sm:py-20 border-t-2 border-black/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading - Pure Minimal Advertising Title */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <h2 className="font-hero text-5xl sm:text-7xl uppercase tracking-tight text-[#fedb3f] leading-none">
            SELECTED CAMPAIGNS
          </h2>
        </div>

        {/* 4 Campaign Visual Cards matching exact original grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {PRODUCTS.map((product, idx) => (
            <div
              key={product.id}
              onClick={() => onSelectProject?.(product.id)}
              className="bg-[#015241] rounded-3xl p-6 border-2 border-white/10 hover:border-[#fedb3f] transition-all duration-300 flex flex-col justify-between group shadow-xl hover:-translate-y-1.5 cursor-pointer"
            >
              {/* Category Tag */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[10px] font-hero tracking-widest uppercase px-2.5 py-1 rounded bg-[#fedb3f] text-black">
                  CASE 0{idx + 1}
                </span>
                <span className="text-[10px] font-bold text-white/50 tracking-wider">
                  2026
                </span>
              </div>

              {/* Centered Graphic Piece */}
              <div className="flex justify-center my-4 group-hover:scale-105 transition-transform duration-300">
                {product.id === 'cheesy-immature' ? (
                  <div className="w-48 sm:w-52 h-64 sm:h-72 rounded-2xl overflow-hidden border-2 border-black/30 shadow-lg relative bg-[#013f32]">
                    <img
                      src="/assets/aistudio/Retrato_elegante_com_sorriso_suave_c6ff7cf3.png"
                      alt="Anna Silva - Retrato"
                      className="w-full h-full object-cover object-center"
                    />
                    <div className="absolute top-2 left-2 bg-[#fedb3f] text-black font-hero text-[9px] px-2 py-0.5 rounded uppercase">
                      PORTRAIT
                    </div>
                  </div>
                ) : (
                  <PouchGraphic
                    color={product.color}
                    textColor={product.textColor}
                    flavorTitle={product.flavor}
                    className="w-48 sm:w-52"
                  />
                )}
              </div>

              {/* Title & Advertising Discipline */}
              <div className="mt-2 text-center pt-3 border-t border-white/10">
                <h3 className="font-hero text-2xl text-white uppercase tracking-wider leading-none">
                  {product.id === 'cheesy-immature' ? 'ANNA SILVA' : product.name}
                </h3>
                <div className="text-[10px] font-bold tracking-widest text-[#fedb3f] uppercase mt-1">
                  {campaignTags[idx]}
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
