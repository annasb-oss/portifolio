import React from 'react';

interface HeaderProps {
  onOpenMenu: () => void;
  onOpenProjects: () => void;
  projectCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenMenu,
  onOpenProjects,
  projectCount = 4
}) => {
  return (
    <header className="w-full bg-[#016450] text-[#fedb3f] px-4 sm:px-8 pt-3 sm:pt-4 pb-2 flex items-center justify-between select-none z-30">
      
      {/* Top Left: Exact Doodle Logo from Screenshot */}
      <div
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className="cursor-pointer group flex items-center gap-2"
        title="Anna Silva - Publicidade & Propaganda"
      >
        <div className="relative w-10 h-8 sm:w-12 sm:h-9 flex items-center justify-center transition-transform group-hover:scale-110">
          <img
            src="/assets/cropped/top_left_doodle_orig.png"
            alt="Anna Silva Logo"
            className="w-full h-full object-contain filter drop-shadow brightness-110"
          />
        </div>
      </div>

      {/* Top Right: Exact Layout with + and Starburst Menu Icon */}
      <div className="flex flex-col items-end">
        {/* Small + above */}
        <span className="text-[#fedb3f] text-xs font-black leading-none mr-8 sm:mr-10">+</span>
        
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenProjects}
            className="font-hero text-lg sm:text-xl tracking-wider text-[#fedb3f] hover:text-white transition-colors cursor-pointer select-none leading-none"
            aria-label="Ver Projetos"
          >
            PROJECTS ({projectCount})
          </button>

          {/* 8-Point Starburst Flower Icon with 3 Menu Bars */}
          <button
            onClick={onOpenMenu}
            className="text-[#fedb3f] hover:text-white transition-transform hover:rotate-12 cursor-pointer p-0.5"
            aria-label="Menu"
            title="Menu"
          >
            <svg viewBox="0 0 24 24" className="w-5 h-5 sm:w-6 sm:h-6 fill-[#fedb3f]">
              <path d="M12 0L14.5 7.5L22.5 5L17.5 12L24 14.5L16.5 17L19 24L12 19L5 24L7.5 17L0 14.5L6.5 12L1.5 5L9.5 7.5L12 0Z" />
              <line x1="8" y1="9" x2="16" y2="9" stroke="#016450" strokeWidth="1.8" strokeLinecap="round" />
              <line x1="8" y1="12" x2="16" y2="12" stroke="#016450" strokeWidth="1.8" strokeLinecap="round" />
              <line x1="8" y1="15" x2="16" y2="15" stroke="#016450" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      </div>

    </header>
  );
};
