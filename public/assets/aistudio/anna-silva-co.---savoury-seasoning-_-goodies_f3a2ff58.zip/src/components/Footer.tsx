import React from 'react';
import { StarburstIcon } from './MascotDoodle';

export const Footer: React.FC = () => {
  return (
    <footer className="relative bg-[#013f32] text-white pt-10 pb-8 border-t-2 border-black/20 select-none">
      
      {/* Decorative starburst */}
      <div className="absolute top-6 right-8 text-[#fedb3f]/20 pointer-events-none">
        <StarburstIcon className="w-12 h-12" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Minimal Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-full bg-[#fedb3f] text-black flex items-center justify-center font-black text-xs font-hero">
              AS
            </span>
            <span className="font-hero text-2xl text-[#fedb3f] tracking-wide">
              ANNA SILVA — PUBLICIDADE & PROPAGANDA
            </span>
          </div>

          <div className="flex items-center gap-6 font-hero text-sm tracking-widest text-white/80 uppercase">
            <span>ART DIRECTION</span>
            <span>•</span>
            <span>BRANDING</span>
            <span>•</span>
            <span>CAMPAIGNS</span>
          </div>
        </div>

        {/* Bottom Line */}
        <div className="mt-8 pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-white/50 tracking-wider">
          <div>
            © {new Date().getFullYear()} ANNA SILVA. ALL RIGHTS RESERVED.
          </div>
          <div>
            PORTFOLIO // PUBLICIDADE & PROPAGANDA
          </div>
        </div>

      </div>
    </footer>
  );
};
