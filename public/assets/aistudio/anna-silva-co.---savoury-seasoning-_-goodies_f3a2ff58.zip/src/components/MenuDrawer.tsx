import React from 'react';

interface MenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (sectionId: string) => void;
}

export const MenuDrawer: React.FC<MenuDrawerProps> = ({
  isOpen,
  onClose,
  onNavigate
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm select-none animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-sm bg-[#016450] text-[#fedb3f] h-full shadow-2xl flex flex-col justify-between border-l-4 border-black/30 z-10 p-6">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-6 border-b border-white/10">
          <span className="font-hero text-2xl tracking-wider text-[#fedb3f]">
            ANNA SILVA
          </span>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-black/30 hover:bg-black/60 flex items-center justify-center text-sm font-bold cursor-pointer text-white"
          >
            ✕
          </button>
        </div>

        {/* Links */}
        <div className="py-8 space-y-5 font-hero text-3xl sm:text-4xl uppercase tracking-wider">
          <div>
            <button
              onClick={() => { onNavigate('hero'); onClose(); }}
              className="hover:text-white transition-colors cursor-pointer block text-left"
            >
              HOME
            </button>
          </div>
          <div>
            <button
              onClick={() => { onNavigate('campaign-visual'); onClose(); }}
              className="hover:text-white transition-colors cursor-pointer block text-left"
            >
              VISUAL DIRECTION
            </button>
          </div>
          <div>
            <button
              onClick={() => { onNavigate('about-me'); onClose(); }}
              className="hover:text-white transition-colors cursor-pointer block text-left"
            >
              SOBRE MIM
            </button>
          </div>
          <div>
            <button
              onClick={() => { onNavigate('campaigns'); onClose(); }}
              className="hover:text-white transition-colors cursor-pointer block text-left"
            >
              CAMPAIGNS
            </button>
          </div>
          <div>
            <button
              onClick={() => { onNavigate('recognition'); onClose(); }}
              className="hover:text-white transition-colors cursor-pointer block text-left"
            >
              AWARDS
            </button>
          </div>
        </div>

        {/* Minimal Footer Tag */}
        <div className="pt-4 border-t border-white/10 text-xs font-hero tracking-widest text-[#fedb3f] uppercase">
          PUBLICIDADE & PROPAGANDA // 2026
        </div>

      </div>
    </div>
  );
};
