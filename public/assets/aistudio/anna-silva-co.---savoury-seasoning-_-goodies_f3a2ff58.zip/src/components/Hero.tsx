import React from 'react';

interface HeroProps {
  onShopNow?: () => void;
  onQuickAdd?: (productId: string) => void;
}

export const Hero: React.FC<HeroProps> = () => {
  return (
    <section id="hero" className="relative bg-[#016450] text-[#fedb3f] select-none pt-6 sm:pt-8 md:pt-10 pb-6 sm:pb-8 overflow-hidden">
      
      {/* Banner Container */}
      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-center">
        <h1 className="font-hero text-[#fdebf3] uppercase font-black tracking-[-0.025em] leading-none text-[15.5vw] sm:text-[13.5vw] md:text-[11.5vw] lg:text-[145px] xl:text-[168px] select-none text-center drop-shadow-[0_6px_16px_rgba(0,0,0,0.3)]">
          ANNA SILVA
        </h1>
      </div>

    </section>
  );
};

