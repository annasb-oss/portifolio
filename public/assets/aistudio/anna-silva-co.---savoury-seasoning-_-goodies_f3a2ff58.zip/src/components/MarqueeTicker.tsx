import React from 'react';

export const MarqueeTicker: React.FC = () => {
  const items = [
    'PUBLICIDADE',
    'PROPAGANDA',
    'ART DIRECTION',
    'BRANDING',
    'CAMPAIGNS',
    'CREATIVE DIRECTION'
  ];

  return (
    <div className="relative w-full bg-[#fedb3f] text-black overflow-hidden py-2 sm:py-2.5 select-none z-20 border-y border-black/10">
      <div className="animate-marquee flex items-center text-xs sm:text-sm font-black tracking-widest uppercase font-sans">
        {/* Repeat sequence for seamless continuous marquee */}
        {Array.from({ length: 4 }).map((_, loopIdx) => (
          <div key={`loop-${loopIdx}`} className="flex items-center gap-6 sm:gap-8 whitespace-nowrap mr-6 sm:mr-8">
            {items.map((item, idx) => (
              <div key={`${loopIdx}-${idx}`} className="flex items-center gap-6 sm:gap-8">
                <span className="text-black font-black text-sm sm:text-base leading-none">+</span>
                <span className="font-hero tracking-widest text-base sm:text-lg">{item}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
